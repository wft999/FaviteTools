# -*- coding: utf-8 -*-

from . import models
from . import ir_http
from . import res_config_settings
from . import ir_model_fields
from . import cfields